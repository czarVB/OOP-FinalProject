﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CardLib
{
    public abstract class Player
    {
        // Instance attributes
        protected String name;
        protected Cards hand;

        // Returns the player's name
        protected abstract String GetName();

        // Sets the player's name
        protected abstract void SetName(String name);

        // The method to grab cards from the board
        protected abstract void PickupCard(Card cardOnBoard);

        //attacking method
        protected abstract void PlayCard(Card cardToPlay);

        // Draw a card from the talon
        protected abstract void DrawFromTalon(int availableNumberOfCards);
    }
}